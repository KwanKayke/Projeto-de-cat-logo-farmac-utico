document.addEventListener('DOMContentLoaded', () => {
    // Arrays de dados dos remédios
    let nomeRemedios = [
        "Dipirona (500 mg)", "Paracetamol (500 mg)", "Ibuprofeno (200 mg)", "Amoxicilina (500 mg)", 
        "Cloridrato de Loratadina (10 mg)", "Omeprazol (20 mg)", "Losartana (50 mg)", 
        "Hidróxido de Alumínio e Magnésio (200 mg)", "Ranitidina (150 mg)", "Ácido Acetilsalicílico (500 mg)", 
        "Metformina (500 mg)", "Atorvastatina (20 mg)", "Fluticasona (50 mcg)", "Clindamicina (300 mg)", 
        "Cefalexina (500 mg)", "Dextrometorfano (20 mg/5 ml)", "Loperamida (2 mg)", "Miconazol (2%)", 
        "Vitamina D3 (1000 UI)", "Lorazepam (2 mg)", "Dipropionato de Betametasona (0,5 mg/g)"
    ];

    let imgRemedios = [
        'IMG/caixa1.jpeg', 'IMG/caixa2.jpeg', 'IMG/caixa3.jpeg', 'IMG/caixa4.jpeg',
        'IMG/caixa1.jpeg', 'IMG/caixa2.jpeg', 'IMG/caixa3.jpeg', 'IMG/caixa4.jpeg',
        'IMG/caixa1.jpeg', 'IMG/caixa2.jpeg', 'IMG/caixa3.jpeg', 'IMG/caixa4.jpeg',
        'IMG/caixa1.jpeg', 'IMG/caixa2.jpeg', 'IMG/caixa3.jpeg', 'IMG/caixa4.jpeg',
        'IMG/caixa1.jpeg', 'IMG/caixa2.jpeg', 'IMG/caixa3.jpeg', 'IMG/caixa4.jpeg',
        'IMG/caixa1.jpeg'
    ];

    // Array para armazenar os remédios reservados
    const cReserva = [];

    // Função que cria as divs automaticamente
    function catalogo() {
        const expCatalogo = document.getElementById('explorar');
        nomeRemedios.forEach((nomes, index) => {
            const divRemedios = document.createElement('div');
            divRemedios.classList.add('remedios');

            // Cria a imagem do remédio
            const img = document.createElement('img');
            img.src = imgRemedios[index];
            img.alt = nomes; // Nome do remédio na imagem

            // Cria botões dentro das divs
            const button = document.createElement('button');
            button.classList.add('botoesDeReserva');
            button.type = 'button';
            button.textContent = 'Reservar';

            // Verificação de reserva
            button.addEventListener('click', () => {
                let pergunta = confirm(`Deseja reservar o medicamento: ${nomes}?`);

                if (pergunta) {
                    cReserva.push(nomes);
                    armazenarReservas(); // Armazena no localStorage
                    alert("Reserva efetuada com sucesso!");
                    atualizaReserva(); // Atualiza a interface
                } else {
                    alert("Produto somente visualizado!");
                }
            });

            // Coloca o nome do remédio embaixo da imagem
            const p = document.createElement('p');
            p.classList.add('textoReserva');
            p.textContent = nomes;

            // Imagem, nome e botão dentro da div do remédio
            divRemedios.appendChild(img);
            divRemedios.appendChild(p);
            divRemedios.appendChild(button);

            // Coloca a div dentro do catálogo
            expCatalogo.appendChild(divRemedios);
        });
    }

    // Função que atualiza as reservas na interface
    function atualizaReserva() {
        const divReservas = document.getElementById('reservas');
        divReservas.innerHTML = ''; // Limpa as reservas
        if (cReserva.length === 0) {
            divReservas.textContent = 'Nenhum remédio reservado.';
        } else {
            cReserva.forEach(remedio => {
                const p = document.createElement('p');
                p.textContent = remedio; // Adiciona o nome do remédio reservado
                divReservas.appendChild(p);
            });
        }
    }

    // Função que armazena as reservas no localStorage
    function armazenarReservas() {
        localStorage.setItem('cReserva', JSON.stringify(cReserva));
    }

    // Função de pesquisa
    function pesquisa() {
        const input = document.getElementById('bpesquisa');
        const sugestoesDiv = document.getElementById('sugestoes'); // Certifique-se de que o ID esteja correto
    
        input.addEventListener('input', function() {
            const query = this.value.toLowerCase();
            sugestoesDiv.innerHTML = ''; // Limpa as sugestões anteriores
            sugestoesDiv.style.display = 'none'; // Esconde a lista inicialmente
    
            if (query) {
                const filteredNames = nomeRemedios.filter(name => name.toLowerCase().includes(query)); 
    
                if (filteredNames.length > 0) {
                    filteredNames.forEach(name => {
                        const sugestoesItem = document.createElement('div');
                        sugestoesItem.classList.add('sugestoes-item');
                        sugestoesItem.textContent = name;
                        sugestoesItem.addEventListener('click', function() {
                            input.value = name; // Preenche o input com o nome selecionado
                            sugestoesDiv.innerHTML = ''; // Limpa as sugestões
                            sugestoesDiv.style.display = 'none'; // Esconde a lista
                        });
                        sugestoesDiv.appendChild(sugestoesItem);
                    });
                    sugestoesDiv.style.display = 'block'; // Mostra a lista de sugestões
                }
            }
        });
    
        // Esconde as sugestões ao clicar fora do input
        document.addEventListener('click', function(event) {
            if (!input.contains(event.target) && !sugestoesDiv.contains(event.target)) {
                sugestoesDiv.style.display = 'none';
            }
        });
    }
    pesquisa();

    // Cria animação de linha flutuante
    const bsup = document.createElement('nav');
    bsup.style.content = "";
    bsup.style.position = "absolute";
    bsup.style.width = "100%";
    bsup.style.height = "2px";
    bsup.style.background = "#003366";
    bsup.style.borderRadius = "5px";
    bsup.style.transform = "scaleX(0)";
    bsup.style.transition = "transform 0.5s ease"; 
    document.body.appendChild(bsup); // Adiciona linha no body

    // Ajusta a linha
    const elementUl = document.querySelector('.barsup');
    if (elementUl) {
        const posicao = elementUl.getBoundingClientRect();
        bsup.style.top = `${posicao.bottom}px`; // Coloca a linha abaixo da ul
    }

    // Função para animar a linha
    function anima() {
        bsup.style.transform = "scaleX(1)";
    }

    // Muda a imagem de reserva
    let reservaBotao = document.getElementById('reserva');
    let reserva = document.getElementById('imagemReserva');

    function transforma() {
        reserva.src = 'IMG/preserva.png';
    }

    function destransforma() {
        reserva.src = 'IMG/iconreserva.png';
    }

    reserva.addEventListener('mouseover', transforma);
    reserva.addEventListener('mouseout', destransforma);

    // Declara que animação de linha flutuante só ativa após o evento de click
    document.getElementById('navegacao').addEventListener('click', anima); 

    // Botão de login
    document.getElementById('login').addEventListener('click', () => {
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1000);
    });

    // Botão de Termos de Uso
    document.getElementById('termos').addEventListener('click', () => {
        setTimeout(() => {
            window.location.href = 'Terms.html';
        }, 1000);
    });

    // Botão de reserva
    document.getElementById('reserva').addEventListener('click', () => {
        setTimeout(() => {
            window.location.href = 'reservas.html';
        }, 1000);
    });

    // Chama a função que cria as divs automaticamente
    catalogo();
});
