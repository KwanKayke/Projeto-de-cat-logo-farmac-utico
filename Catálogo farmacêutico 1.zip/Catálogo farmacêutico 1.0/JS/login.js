document.addEventListener('DOMContentLoaded', () => {
    var usuario = document.getElementById('usua');
    var sen = document.getElementById('sen');
    var msgUsuario = document.getElementById('msg_u');
    var msgSenha = document.getElementById('msg_s');

    // Função de login
    function login() {
        var valorUsuario = usuario.value.trim().toUpperCase();
        var valorSenha = sen.value;
        msgUsuario.textContent = '';
        msgSenha.textContent = '';

        // Busca a senha armazenada no localStorage
        const storedPassword = localStorage.getItem(valorUsuario);

        // Verifica se os campos estão vazios
        if (!valorUsuario || !valorSenha) {
            if (!valorUsuario) msgUsuario.textContent = "Usuário é obrigatório";
            if (!valorSenha) msgSenha.textContent = "Senha é obrigatória";
            return;
        }

        // Verifica se o usuário existe no localStorage
        if (!storedPassword) {
            msgSenha.textContent = "Usuário não encontrado. Por favor, verifique se já possui uma conta.";
            return;
        }

        // Compara a senha armazenada com a fornecida
        if (storedPassword === valorSenha) {
            alert("Bem-vindo " + valorUsuario + "!");
            window.location.href = 'index.html';
        } else {
            msgSenha.textContent = "Senha incorreta.";
        }
    }

    // Função para redirecionar para a página de cadastro
    function redCria() {
        window.location.href = 'Cad.html';
    }

    // Adiciona os ouvintes de evento
    document.getElementById('Login').addEventListener('click', login);
    document.getElementById('redirectCria').addEventListener('click', redCria);

});