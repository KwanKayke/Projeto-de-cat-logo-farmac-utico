// Função para recuperar e imprimir reservas do localStorage
function imprimirReservas() {
    const reservas = localStorage.getItem('cReserva');
    const reservasDiv = document.getElementById('reservas');

    if (reservas) {
        const reservasArray = JSON.parse(reservas);
        reservasDiv.innerHTML = '<ul>' + reservasArray.map(reserva => `<li>${reservas}</li>`).join('') + '</ul>';
    } else {
        reservasDiv.innerHTML = '<p>Nenhuma reserva encontrada.</p>';
    }
}
//função de limpar todas as reservas
function limparReservas() {
    localStorage.removeItem('cReserva');
    imprimirReservas(); // Atualiza a exibição após limpar
}

// Chama a função ao carregar a página
window.onload = imprimirReservas;

document.getElementById('limparReservas').onclick = limparReservas;