document.addEventListener('DOMContentLoaded',() => {
    //cria animação de linha flutuante
    const bsup = document.createElement('nav');
    bsup.style.content = "";
    bsup.style.position = "absolute";
    bsup.style.width = "100%";
    bsup.style.height = "2px";
    bsup.style.background = "#003366";
    bsup.style.borderRadius = "5px";
    bsup.style.transform = "scaleX(0)";
    bsup.style.transition = "transform 0.5s ease"; 
    document.body.appendChild(bsup);//linha no corpo do site
    const ajustaLinha = document.querySelector('.barsup').onsetHeigth;
    bsup.style.top = `${ajustaLinha}px`



    function anima() {
        bsup.style.transform = "scaleX(1)";
        return;
       
        
    }




    
    document.addEventListener('click', anima);// declara que só ativa após o evento de click
    //botão de login
    document.getElementById('login').addEventListener('click', () => {
        setTimeout(()=>{
            window.location.href = 'login.html'
        },1000)
    })
    //botão de Termos de Uso
    document.getElementById('termos').addEventListener('click', ()=>{
        setTimeout(()=>{
            window.location.href = 'Terms.html'
        },1000)
    })


    
    
    


})

