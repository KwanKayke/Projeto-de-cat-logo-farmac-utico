document.addEventListener('DOMContentLoaded', () => {
    var nome = document.getElementById('criaUser');
    var senha = document.getElementById('criaSenha');
    var v_senha = document.getElementById('confereSen');
    const msgUser = document.getElementById('msgNome');
    const msgSen = document.getElementById('msgSenha');

    // Função para alternar a visibilidade da senha
    function tipoSenha() {
        let tipo = sen.type;
        if (tipo === 'password') {
            sen.type = 'text'; // Torna a senha visível
        } else {
            sen.type = 'password'; // Torna a senha invisível
        }
    }
    //função de verificação e criação de usuário
    function criarLog() {
        const vNome = nome.value.trim().toUpperCase();
        const vSenha = senha.value;
        const vvSenha = v_senha.value;
        msgUser.textContent = '';
        msgSen.textContent = '';

        if (!vNome || !vSenha || !vvSenha) {
            if (!vNome) msgUser.textContent = "Usuário é obrigatório";
            if (!vSenha) msgSen.textContent = "Senha é obrigatória";
            if (!vvSenha) msgSen.textContent = "Confirmação de senha é obrigatória";
            return;
        }
        else if (vSenha !== vvSenha) {
            msgSen.textContent = "As senhas não conferem";
            return;
        } 
        else {
            localStorage.setItem(vNome, vSenha);
            alert("Conta criada com sucesso! Redirecionando para o login...");
            window.location.href = 'login.html'; 
        }
        
    }

    document.getElementById('criaConta').addEventListener('click', criarLog);
    document.getElementById('visuSen').addEventListener('click', tipoSenha); // torna senha visível/oculta ao click
});
