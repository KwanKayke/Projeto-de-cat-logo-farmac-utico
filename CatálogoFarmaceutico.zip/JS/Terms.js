
//botão de retortar a página anterior
document.getElementById('voltar').addEventListener('click',()=> {
    window.history.back();
})
//botão de retornar para página principal
document.getElementById('inicio').addEventListener('click',()=>{
    window.location.href = 'index.html';
})